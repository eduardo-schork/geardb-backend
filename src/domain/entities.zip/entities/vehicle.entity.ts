export type TVehicleEntity = {
    id: string;
    brand: string;
    model: string;
    year: number;
    bodyType: string;
    fuelType: string;
    transmission: string;
    createdAt: Date;
    updatedAt: Date;
    deletedAt?: Date | null;
};
