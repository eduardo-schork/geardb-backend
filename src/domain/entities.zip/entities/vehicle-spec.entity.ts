export type TVehicleSpecEntity = {
    id: string;
    vehicleId: string;
    engine: string;
    power: string;
    torque: string;
    weight: string;
    doors: number;
    createdAt: Date;
    updatedAt: Date;
    deletedAt?: Date | null;
};
